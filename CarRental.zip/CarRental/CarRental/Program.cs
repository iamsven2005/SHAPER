using CarRental.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Retrieve the connection string from appsettings.json
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Configure Entity Framework to use PostgreSQL
builder.Services.AddDbContext<ExpensesDBContext>(options =>
    options.UseNpgsql(connectionString)
);

var app = builder.Build();

// Configure logging
var logger = app.Services.GetRequiredService<ILogger<Program>>();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Test the database connection and log the result
try
{
    using (var scope = app.Services.CreateScope())
    {
        var dbContext = scope.ServiceProvider.GetRequiredService<ExpensesDBContext>();
        dbContext.Database.EnsureCreated();
        logger.LogInformation("Successfully connected to the PostgreSQL database.");
    }
}
catch (Exception ex)
{
    logger.LogError(ex, "An error occurred while connecting to the PostgreSQL database.");
}

app.Run();
