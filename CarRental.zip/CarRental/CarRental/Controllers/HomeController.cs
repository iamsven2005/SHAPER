using CarRental.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;

namespace CarRental.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ExpensesDBContext _context;

        public HomeController(ILogger<HomeController> logger, ExpensesDBContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Expenses(string sortOrder, string category)
        {
            ViewBag.ValueSortParm = string.IsNullOrEmpty(sortOrder) ? "value_desc" : "";
            var expenses = _context.Expenses.Include(e => e.ExpenseDetails).AsQueryable();

            if (!string.IsNullOrEmpty(category))
            {
                expenses = expenses.Where(e => e.Category == category);
            }

            switch (sortOrder)
            {
                case "value_desc":
                    expenses = expenses.OrderByDescending(e => e.Value);
                    break;
                default:
                    expenses = expenses.OrderBy(e => e.Value);
                    break;
            }

            var total = expenses.Sum(x => x.Value);
            ViewBag.Total = total;
            return View(expenses.ToList());
        }

        public IActionResult CreateEditExpense(int? id)
        {
            Expenses expensedb = null;
            if (id != null)
            {
                expensedb = _context.Expenses.Include(e => e.ExpenseDetails).SingleOrDefault(x => x.Id == id);
                if (expensedb == null)
                {
                    return NotFound();
                }
            }
            else
            {
                expensedb = new Expenses();
            }
            return View(expensedb);
        }

        public IActionResult DeleteExpense(int id)
        {
            var expensedb = _context.Expenses.Include(e => e.ExpenseDetails).SingleOrDefault(x => x.Id == id);
            if (expensedb == null)
            {
                return NotFound();
            }
            _context.Expenses.Remove(expensedb);
            _context.SaveChanges();
            return RedirectToAction("Expenses");
        }

        [HttpPost]
        public IActionResult CreateEditExpenseForm(Expenses model)
        {
            if (model.Id == 0)
            {
                _context.Expenses.Add(model);
            }
            else
            {
                _context.Expenses.Update(model);

                var existingDetails = _context.ExpenseDetails.Where(ed => ed.ExpensesId == model.Id).ToList();

                // Update or add new details
                foreach (var detail in model.ExpenseDetails)
                {
                    if (!detail.IsDeleted)
                    {
                        if (detail.Id == 0)
                        {
                            _context.ExpenseDetails.Add(detail);
                        }
                        else
                        {
                            var existingDetail = existingDetails.FirstOrDefault(ed => ed.Id == detail.Id);
                            if (existingDetail != null)
                            {
                                existingDetail.Description = detail.Description;
                                existingDetail.Value = detail.Value;
                                _context.ExpenseDetails.Update(existingDetail);
                            }
                        }
                    }
                }

                // Remove deleted details
                foreach (var existingDetail in existingDetails)
                {
                    if (model.ExpenseDetails.Any(ed => ed.Id == existingDetail.Id && ed.IsDeleted))
                    {
                        _context.ExpenseDetails.Remove(existingDetail);
                    }
                }
            }

            _context.SaveChanges();
            return RedirectToAction("Expenses");
        }




        public IActionResult SearchExpenses(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                ViewBag.Message = "No search term provided.";
                return View("Expenses", new List<Expenses>());
            }

            var searchResults = _context.Expenses
                .Include(e => e.ExpenseDetails)
                .Where(x => x.Description.Contains(searchTerm) || x.Value.ToString().Contains(searchTerm))
                .ToList();

            if (!searchResults.Any())
            {
                ViewBag.Message = "No results found.";
            }

            var total = searchResults.Sum(x => x.Value);
            ViewBag.Total = total;
            return View("Expenses", searchResults);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
