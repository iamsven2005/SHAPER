﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CarRental.Models
{
    public class Expenses
    {
        public int Id { get; set; }
        public int Value { get; set; }
        [Required]
        public string Description { get; set; }
        public string Category { get; set; }
        public List<ExpenseDetail> ExpenseDetails { get; set; } = new List<ExpenseDetail>();
    }

    public class ExpenseDetail
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public int Value { get; set; }
        public int ExpensesId { get; set; }
        public Expenses Expenses { get; set; }
        public bool IsDeleted { get; set; } // Add this property
    }


}
