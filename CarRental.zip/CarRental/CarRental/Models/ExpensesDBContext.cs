﻿using Microsoft.EntityFrameworkCore;

namespace CarRental.Models
{
    public class ExpensesDBContext : DbContext
    {
        public DbSet<Expenses> Expenses { get; set; }
        public DbSet<ExpenseDetail> ExpenseDetails { get; set; }

        public ExpensesDBContext(DbContextOptions<ExpensesDBContext> options)
            : base(options)
        {
        }
    }
}
