namespace _221619Q_ESD_PA.ViewModels
{
    public class JoinDateCountViewModel
    {
        public DateTime JoinDate { get; set; }
        public int Count { get; set; }
    }
}
