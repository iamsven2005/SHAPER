﻿namespace _221619Q_ESD_PA.Models
{
    public class Player
    {
        public int PlayerID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public DateTime JoinDate { get; set; }
        public ICollection<GameScore> GameScores { get; set; }
    }
}
