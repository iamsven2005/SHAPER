﻿namespace _221619Q_ESD_PA.Models
{
    public class GameScore
    {
        public int GameScoreID { get; set; }
        public int Score { get; set; }
        public int PlayerID { get; set; }
        public int GameID { get; set; }
        public Player Player { get; set; }
        public Game Game { get; set; }
    }
}
