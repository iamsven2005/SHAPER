﻿using Microsoft.EntityFrameworkCore;

namespace _221619Q_ESD_PA.Models
{
    public class GameScoreContext : DbContext
    {
        public DbSet<Player> Players { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<GameScore> GameScores { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("GameStore");
        }
    }

}
