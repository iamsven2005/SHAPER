﻿namespace _221619Q_ESD_PA.Models
{
    public class Game
    {
        public int GameID { get; set; }
        public string Name { get; set; }
        public string Genre { get; set; }
        public ICollection<GameScore> GameScores { get; set; }
    }
}
