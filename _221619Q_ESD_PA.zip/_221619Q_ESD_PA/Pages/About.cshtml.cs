﻿using _221619Q_ESD_PA.Models;
using _221619Q_ESD_PA.ViewModels;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;

namespace _221619Q_ESD_PA.Pages
{
    public class AboutModel : PageModel
    {
        private readonly GameScoreContext _context;

        public AboutModel(GameScoreContext context)
        {
            _context = context;
        }

        public List<JoinDateCountViewModel> PlayerJoinDates { get; set; }

        public void OnGet()
        {
            PlayerJoinDates = _context.Players
                .GroupBy(p => p.JoinDate)
                .Select(g => new JoinDateCountViewModel
                {
                    JoinDate = g.Key,
                    Count = g.Count()
                })
                .OrderBy(j => j.JoinDate)
                .ToList();
        }
    }
}
