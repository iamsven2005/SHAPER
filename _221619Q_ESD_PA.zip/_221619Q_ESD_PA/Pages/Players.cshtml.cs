using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Linq;
using System.Collections.Generic;

namespace _221619Q_ESD_PA.Pages
{
    public class PlayersModel : PageModel
    {
        private readonly GameScoreContext _context;
        public List<Player> Players { get; set; } = new List<Player>();

        [BindProperty]
        public Player PlayerProperty { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchString { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SortOrder { get; set; }

        [BindProperty(SupportsGet = true)]
        public int PageNumber { get; set; } = 1;

        public int TotalPages { get; set; }

        private const int PageSize = 5;

        public PlayersModel(GameScoreContext context)
        {
            _context = context;
        }

        public void OnGet()
        {
            IQueryable<Player> playersIQ = from p in _context.Players select p;

            if (!string.IsNullOrEmpty(SearchString))
            {
                playersIQ = playersIQ.Where(p => p.FirstName.Contains(SearchString) || p.LastName.Contains(SearchString));
            }

            switch (SortOrder)
            {
                case "firstName":
                    playersIQ = playersIQ.OrderBy(p => p.FirstName);
                    break;
                case "firstName_desc":
                    playersIQ = playersIQ.OrderByDescending(p => p.FirstName);
                    break;
                case "lastName":
                    playersIQ = playersIQ.OrderBy(p => p.LastName);
                    break;
                case "lastName_desc":
                    playersIQ = playersIQ.OrderByDescending(p => p.LastName);
                    break;
                case "joinDate":
                    playersIQ = playersIQ.OrderBy(p => p.JoinDate);
                    break;
                case "joinDate_desc":
                    playersIQ = playersIQ.OrderByDescending(p => p.JoinDate);
                    break;
                default:
                    playersIQ = playersIQ.OrderBy(p => p.PlayerID);
                    break;
            }

            int totalPlayers = playersIQ.Count();
            TotalPages = (int)Math.Ceiling(totalPlayers / (double)PageSize);

            Players = playersIQ.Skip((PageNumber - 1) * PageSize).Take(PageSize).ToList();
        }

        public IActionResult OnPost()
        {
            _context.Players.Add(PlayerProperty);
            _context.SaveChanges();
            return RedirectToPage();
        }
    }
}
