using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Linq;

namespace _221619Q_ESD_PA.Pages
{
    public class EditPlayerModel : PageModel
    {
        private readonly GameScoreContext _context;

        public EditPlayerModel(GameScoreContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Player Player { get; set; }

        // Load the player data when the page is accessed via GET
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Player = await _context.Players.FindAsync(id);

            if (Player == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var playerToUpdate = await _context.Players.FindAsync(Player.PlayerID);

            if (playerToUpdate == null)
            {
                return NotFound();
            }

            // Update the existing player's details
            playerToUpdate.FirstName = Player.FirstName;
            playerToUpdate.LastName = Player.LastName;
            playerToUpdate.JoinDate = Player.JoinDate;

            try
            {
                // Save changes to the database
                await _context.SaveChangesAsync();

                // Add logging to confirm saving
                Console.WriteLine("Player updated successfully");
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlayerExists(Player.PlayerID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Players");
        }

        private bool PlayerExists(int id)
        {
            return _context.Players.Any(e => e.PlayerID == id);
        }
    }
}
