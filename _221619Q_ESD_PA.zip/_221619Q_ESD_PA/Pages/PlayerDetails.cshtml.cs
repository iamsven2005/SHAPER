using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Linq;

namespace _221619Q_ESD_PA.Pages
{
    public class PlayerDetailsModel : PageModel
    {
        private readonly GameScoreContext _context;

        public PlayerDetailsModel(GameScoreContext context)
        {
            _context = context;
        }

        public Player Player { get; set; }

        public IActionResult OnGet(int id)
        {
            Player = _context.Players.FirstOrDefault(p => p.PlayerID == id);

            if (Player == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}
