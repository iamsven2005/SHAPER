using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace _221619Q_ESD_PA.Pages
{
    public class DeleteGameModel : PageModel
    {
        private readonly GameScoreContext _context;

        public DeleteGameModel(GameScoreContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Game Game { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Game = await _context.Games.FindAsync(id);

            if (Game == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var player = await _context.Games.FindAsync(Game.GameID);

            if (player == null)
            {
                return NotFound();
            }

            _context.Games.Remove(player);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Games");
        }
    }
}
