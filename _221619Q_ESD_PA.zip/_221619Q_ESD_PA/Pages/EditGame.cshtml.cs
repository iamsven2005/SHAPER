using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace _221619Q_ESD_PA.Pages
{
    public class EditGameModel : PageModel
    {
        private readonly GameScoreContext _context;

        public EditGameModel(GameScoreContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Game Game { get; set; }
        public async Task<IActionResult> OnGetAsync(int id)
        {
            Game = await _context.Games.FindAsync(id);

            if (Game == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var playerToUpdate = await _context.Games.FindAsync(Game.GameID);

            if (playerToUpdate == null)
            {
                return NotFound();
            }
            _context.Games.Remove(playerToUpdate);
            var newPlayer = new Game
            {
                GameID = Game.GameID,
                Name = Game.Name,
                Genre = Game.Genre,
            };

            // Add the new player to the context
            _context.Games.Add(newPlayer);

            try
            {
                // Save changes to the database
                await _context.SaveChangesAsync();

                // Add logging to confirm saving
                Console.WriteLine("Player updated successfully");
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlayerExists(Game.GameID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Players");
        }

        private bool PlayerExists(int id)
        {
            return _context.Games.Any(e => e.GameID == id);
        }
    }
}
