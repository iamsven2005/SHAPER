using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace _221619Q_ESD_PA.Pages
{
    public class GameDetailsModel : PageModel
    {
        private readonly GameScoreContext _context;

        public GameDetailsModel(GameScoreContext context)
        {
            _context = context;
        }

        public Game Game { get; set; }

        [BindProperty]
        public GameScore NewGameScore { get; set; }

        public List<SelectListItem> PlayersSelectList { get; set; }

        public IActionResult OnGet(int id)
        {
            LoadGameAndPlayers(id);
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                LoadGameAndPlayers(NewGameScore.GameID);
                return Page();
            }

            // Add the new GameScore to the database
            _context.GameScores.Add(NewGameScore);
            _context.SaveChanges();

            // Reload the game details to reflect the new score
            LoadGameAndPlayers(NewGameScore.GameID);

            return RedirectToPage(new { id = NewGameScore.GameID });
        }

        private void LoadGameAndPlayers(int gameId)
        {
            Game = _context.Games
                .Include(g => g.GameScores)
                .ThenInclude(gs => gs.Player)
                .FirstOrDefault(g => g.GameID == gameId);

            PlayersSelectList = _context.Players
                .Select(p => new SelectListItem
                {
                    Value = p.PlayerID.ToString(),
                    Text = $"{p.FirstName} {p.LastName}"
                }).ToList();

            NewGameScore = new GameScore
            {
                GameID = gameId
            };
        }
    }
}
