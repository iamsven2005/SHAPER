using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace _221619Q_ESD_PA.Pages
{
    public class DeletePlayerModel : PageModel
    {
        private readonly GameScoreContext _context;

        public DeletePlayerModel(GameScoreContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Player Player { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Player = await _context.Players.FindAsync(id);

            if (Player == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var player = await _context.Players.FindAsync(Player.PlayerID);

            if (player == null)
            {
                return NotFound();
            }

            _context.Players.Remove(player);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Players");
        }
    }
}
