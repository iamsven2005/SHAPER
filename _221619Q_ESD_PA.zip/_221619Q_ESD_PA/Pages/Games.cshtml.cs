using _221619Q_ESD_PA.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;

namespace _221619Q_ESD_PA.Pages
{
    public class GamesModel : PageModel
    {
        private readonly GameScoreContext _context;
        public List<Game> Games { get; set; } = new List<Game>();

        [BindProperty]
        public Game GameProperty { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchString { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SortOrder { get; set; }

        [BindProperty(SupportsGet = true)]
        public int PageNumber { get; set; } = 1;

        public int TotalPages { get; set; }

        private const int PageSize = 5;

        public GamesModel(GameScoreContext context)
        {
            _context = context;
        }

        public void OnGet()
        {
            IQueryable<Game> gamesIQ = from g in _context.Games select g;

            if (!string.IsNullOrEmpty(SearchString))
            {
                gamesIQ = gamesIQ.Where(g => g.Name.Contains(SearchString) || g.Genre.Contains(SearchString));
            }

            switch (SortOrder)
            {
                case "name":
                    gamesIQ = gamesIQ.OrderBy(g => g.Name);
                    break;
                case "name_desc":
                    gamesIQ = gamesIQ.OrderByDescending(g => g.Name);
                    break;
                case "genre":
                    gamesIQ = gamesIQ.OrderBy(g => g.Genre);
                    break;
                case "genre_desc":
                    gamesIQ = gamesIQ.OrderByDescending(g => g.Genre);
                    break;
                default:
                    gamesIQ = gamesIQ.OrderBy(g => g.GameID);
                    break;
            }

            int totalGames = gamesIQ.Count();
            TotalPages = (int)Math.Ceiling(totalGames / (double)PageSize);

            Games = gamesIQ.Skip((PageNumber - 1) * PageSize).Take(PageSize).ToList();
        }

        public IActionResult OnPost()
        {
            _context.Games.Add(GameProperty);
            _context.SaveChanges();
            return RedirectToPage();
        }
    }
}
